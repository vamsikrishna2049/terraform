def lambda_handler(event, context):

    return "Triggered by RDS Lambda!"
